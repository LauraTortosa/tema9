<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class FrasesController extends AbstractController
{
    #[Route('/', name: 'app_frases')]
    public function index(): Response
    {
        $frases = [
            'Lo mejor de la vida es gratis.',
            'Es elegante ser buena persona.',
            'Llora litros, sonríe a mares.',
        ];

        $frase = $frases[array_rand($frases)];

        return $this->render('frases/index.html.twig', [
            'frase' => $frase,
        ]);


    }
}
